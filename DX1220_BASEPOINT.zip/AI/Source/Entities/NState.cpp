﻿#include "NState.h"

NState::NState(NStateMachine* machine) : sm(machine) { }

